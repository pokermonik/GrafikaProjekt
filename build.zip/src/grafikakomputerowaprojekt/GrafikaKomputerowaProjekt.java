/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package grafikakomputerowaprojekt;

import java.awt.MouseInfo;
import java.io.IOException;

/**
 *
 * @author poker
 */
public class GrafikaKomputerowaProjekt {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
            //PPMreader ppm = new PPMreader();
            MenuJFrame menu = new MenuJFrame();
            menu.setVisible(true);
            
           // ColorConverterFrame cccframe = new ColorConverterFrame();
            //ppm.displayImage(ppm.readP3("ppm2.ppm"));
            //JPGreader jpg= new JPGreader("website.jpg");
            //jpg.displayImage(jpg.getImage());
            //MojaRamka MojaRamkaX = new MojaRamka();
            //while(1>0)
            {
               //System.out.println(MouseInfo.getPointerInfo().getLocation().getX()); 
            }
            
        // TODO code application logic here
    }
    
}
